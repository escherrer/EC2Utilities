#region License
//
// Your Project Name Here: ThisAssembly.cs
//
// Author:
//   Your Name Here (insert-your@email.here)
//
// Copyright (C) 2012 Your Name Here
//
// [License Body Here]
#endregion

static class ThisAssembly
{
	internal const string Title = "CSharpTemplate";
	internal const string Author = "Your Name Here";
	internal const string Copyright = "Copyright (C) 2012 " + Author;
	internal const string Version = "1.0.0.0"; //alfa?
	internal const string InformationalVersion = "1.0.0.0";
}