using System;
namespace CommandLine.Tests
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

